create view maxincome as
select `people_db`.`users`.`fname`        AS `First_NAME`,
       `people_db`.`users`.`lname`        AS `Last_NAME`,
       `people_db`.`private_inf`.`income` AS `INCOME`
from (`people_db`.`users`
       join `people_db`.`private_inf` on ((`people_db`.`users`.`id` = `people_db`.`private_inf`.`id`)))
where (`people_db`.`private_inf`.`income` >
       (select avg(`people_db`.`private_inf`.`income`) from `people_db`.`private_inf`));

